#include <ros/ros.h>
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

// Include msgs 
#include <std_msgs/Float32.h>
#include <sensor_msgs/Image.h>
#include <geometry_msgs/Pose2D.h>

ros::Publisher d_pub_; // Publisher untuk distance 
ros::Publisher centroid_pub_; // Publisher untuk point moment (centroid yang putih)
//ros::Publisher c_pub_; // Publisher untuk center point of image

int sizeofImage[2],halfofImage[2],centerofImage[2],val;
float robot_d,p_d;

void imageCallback(const sensor_msgs::ImageConstPtr& msg)
{
  std::cout<<"Entering Callback"<<std::endl;
  try
  {
    /* code */
    //Pointer
    cv_bridge::CvImagePtr img;
    std_msgs::Float32 float32;
    geometry_msgs::Pose2D centroid_pix;
//    geometry_msgs::Pose2D image_center;
    // Convert Ros Image to Cv image
    img = cv_bridge::toCvCopy(msg, sensor_msgs::image_encodings::MONO8); // container of type sensor_msgs/Image
    cv::Mat mat_image = img->image;
    sizeofImage[0]    = mat_image.size().width;
    halfofImage[0]    = sizeofImage[0]/2;
    sizeofImage[1]    = mat_image.size().height;
    halfofImage[1]    = sizeofImage[1]/2;
    val            = halfofImage[0]-1;
    centerofImage[0]  = val;
    val            = halfofImage[1]-1;
    centerofImage[1]  = val;
    // Find moments and point of the image 
    cv::Moments m= moments(mat_image,true);
    cv::Point p(m.m10/m.m00, m.m01/m.m00); 
    std::cout<<"Moment of Image : "<<p.x<<" , "<<p.y<<std::endl;
    // Find distance between centerofImage and momens point
    p_d = sqrt(((p.x-centerofImage[0])*(p.x-centerofImage[0])) + ((p.y-centerofImage[1])*(p.y-centerofImage[1])));
    // Estimate real distance with this function (used regression to get this function)
    // Inserted regression function : from 0-9 Polinom 6
    robot_d = 0.000000000000006*(p_d*p_d*p_d*p_d*p_d*p_d)-0.000000000008*(p_d*p_d*p_d*p_d*p_d)+0.000000004*(p_d*p_d*p_d*p_d)-0.0000007*(p_d*p_d*p_d)+0.00005*(p_d*p_d)+0.0138*p_d+0.0018;
    // Inserted regression function : from 0-9 Polinom 5
    //robot_d = 0.000000000002*(p_d*p_d*p_d*p_d*p_d)-0.000000002*(p_d*p_d*p_d*p_d)+0.0000009*(p_d*p_d*p_d)-0.0002*(p_d*p_d)-0.0108;
    // Inserted regression function : from 0-9 Polinom 4
    //robot_d = 0.0000000003*(p_d*p_d*p_d*p_d)-0.00000003*(p_d*p_d*p_d)+0.00005*(p_d*p_d)+0.0086*p_d+0.0568;
    // Inserted regression function : from 0-9 Polinom 3
    //robot_d = 0.00000005*(p_d*p_d*p_d)-0.00003*(p_d*p_d)+0.00189*p_d-0.0679;
    // Inserted regression function : from 0-9 Polinom 2
    //robot_d = 0.000009*(p_d*p_d)+0.0114*p_d+0.1498;
    // Inserted regression function : from 0-9 Linear
    //robot_d = 0.00163*p_d-0.2277;
    // Inserted regression function : from 1-9 Linear
    //robot_d = 0.0166*p_d-0.3641;
    // Inserted regression function : from 1-9 Polinom 2
    //robot_d = 0.00001*(p_d*p_d)+0.0093*p_d+0.4496;
    // Inserted regression function : from 1-9 Polinom 3
    //robot_d = 0.00000007*(p_d*p_d*p_d)-0.00005*(p_d*p_d)+0.0244*p_d-0.4897;
    // Inserted regression function : from 1-9 Polinom 4
    //robot_d = 0.0000000006*(p_d*p_d*p_d*p_d)-0.0000006*(p_d*p_d*p_d)+0.0002*(p_d*p_d)-0.0163*p_d+1.2969;
    // Inserted regression function : from 1-9 Polinom 5
    //robot_d = 0.000000000003*(p_d*p_d*p_d*p_d*p_d)-0.000000004*(p_d*p_d*p_d*p_d)+0.000002*(p_d*p_d*p_d)-0.0004*(p_d*p_d)+0.0527*p_d-1.1496;
    // Inserted regression function : from 1-9 Polinom 6
    //robot_d = 0.00000000000016*(p_d*p_d*p_d*p_d*p_d*p_d)-0.00000000002*(p_d*p_d*p_d*p_d*p_d)+0.00000001*(p_d*p_d*p_d*p_d)-0.000004*(p_d*p_d*p_d)+0.0006*(p_d*p_d)-0.0337*p_d+1.4881; 
    
    float32.data = robot_d; // Memindahkan nilai jarak pixel centroid ke centerofImage ke variabel float32 data 
    centroid_pix.x = p.x; centroid_pix.y = p.y;  // Memindahkan nilai lokasi centroid objek ke variabel pix x dan pix y
//    image_center.x = centerofImage[0]; image_center.y = centerofImage[1];
    
    // Publish variabel msg 
    d_pub_.publish(float32);
    centroid_pub_.publish(centroid_pix);
//    c_pub_.publish(image_center);

    // Print coordinate of centroid
    std::cout<<"Size of image : "<<sizeofImage[0]<<" , "<<sizeofImage[1]<<std::endl;
    std::cout<<"Half of image : "<<halfofImage[0]<<" , "<<halfofImage[1]<<std::endl;
    std::cout<<"Center of image : "<<centerofImage[0]<<" , "<<centerofImage[1]<<std::endl;
    std::cout<<"Ball to center distance : "<<p_d<<std::endl;
    std::cout<<"Counted Robot to Ball Distance : "<<robot_d<<std::endl;
  }

  catch(cv_bridge::Exception& e)
  {
    ROS_ERROR("Couldn't convert from '%s' to 'mono8'.", msg->encoding.c_str());
  }
};

int main(int argc, char **argv)
{
  ros::init(argc, argv, "image_listener");
  ros::NodeHandle nh;
  image_transport::ImageTransport it(nh);
  //image_transport::Subscriber sub = it.subscribe("nubot2/morphology_filtered_image", 1, imageCallback);
  image_transport::Subscriber sub = it.subscribe("input_image", 1, imageCallback);
  d_pub_ = nh.advertise<std_msgs::Float32>("output_value",1);
  centroid_pub_ = nh.advertise<geometry_msgs::Pose2D>("centroid",1);
//  c_pub_ = nh.advertise<geometry_msgs::Pose2D>("centerofImage",1);
  ros::spin();
  return 0;
}