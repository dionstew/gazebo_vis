/*
* Merupakan Filter untuk menyaring data pada topic nubot1/odom
* yang diambil merupakan position x, y, z saja.
* Meski ingin mengambil data orientation juga supaya dapat data derajat Euler,
* Kurasa tidak perlu digunakan karena algoritma sistem tidak membutuhkannya.
*/

// ROS 
#include "ros/ros.h"

// Message
#include "std_msgs/String.h"
#include <nav_msgs/Odometry.h>
#include <nubot_mapping/Pose2D.h>


ros::Publisher pub_pose_;

void odometryCallback(const nav_msgs::Odometry::ConstPtr msg)
{
  nubot_mapping::Pose2D pose2d;
  pose2d.x = msg->pose.pose.position.x;
  pose2d.y = msg->pose.pose.position.y;
  pose2d.z = msg->pose.pose.position.z;
  
  pub_pose_.publish(pose2d);
}

int main(int argc, char **argv)
{
  ros::init(argc, argv, "odom_filter");

  ros::NodeHandle nh;

  ros::Subscriber sub_odom_ = nh.subscribe("input_value",1,odometryCallback);
  
  pub_pose_ = nh.advertise<nubot_mapping::Pose2D>("output_value",1);
  
  ros::spin();

  return 0;
}
