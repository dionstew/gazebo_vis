// ROS
#include <ros/ros.h>

// Declare messages
#include <nubot_mapping/Pose2D.h>

// Subscriber : untuk mengambil data dari topik 
#include <geometry_msgs/Pose2D.h> 
#include <std_msgs/Float32.h>

/*
  Deklarasi variabel untuk menyimpan data dari msg 
  topik yang di subscribe. 
*/
float n1_p_x,n2_p_x,n3_p_x;
float n1_p_y,n2_p_y,n3_p_y;
float n1_d,n2_d,n3_d;
int centerofImage[2]={539,539};

/*
 * Deklarasi variabel ros untuk publish data hasil 
 * estimasi. -> pub_ 
 */
ros::Publisher pub_;

struct piksel
{
  int x;
  int y;
};

struct ObjectsCoordinate
{
  float x;
  float y;
};

// Variabel untuk menyimpan delta piksel  
piksel nb1_delta_pix;
piksel nb2_delta_pix;
piksel nb2_delta_pix;

// Variabel untuk menyimpan centroid objek (menyimpan data dari subscriber)
piksel nb1_centroid;
piksel nb2_centroid;
piksel nb3_centroid;

// Variabel untuk menyimpan hasil hitungan sementara
piksel nubot_centroid_delta[3];

ObjectsCoordinate nubot_centroid_delta_lapangan[3];

// Fungsi untuk mengalikan posisi piksel objek dengan persamaan regresi
ObjectsCoordinate kaliregresi(piksel posisipiksel)
{
  ObjectCoordinate rb;
  rb.x = 0.000000000000006*(posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x)-0.000000000008*(posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x)+0.000000004*(posisipiksel.x*posisipiksel.x*posisipiksel.x*posisipiksel.x)-0.0000007*(posisipiksel.x*posisipiksel.x*posisipiksel.x)+0.00005*(posisipiksel.x*posisipiksel.x)+0.0138*posisipiksel.x+0.0018;
  rb.y = 0.000000000000006*(posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y)-0.000000000008*(posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y)+0.000000004*(posisipiksel.y*posisipiksel.y*posisipiksel.y*posisipiksel.y)-0.0000007*(posisipiksel.y*posisipiksel.y*posisipiksel.y)+0.00005*(posisipiksel.y*posisipiksel.y)+0.0138*posisipiksel.y+0.0018;
  return rb;
}
void nubot1_p_Callback(const nubot_mapping::Pose2D::ConstPtr msg)
{ 
  n1_p_x = msg->x;
  n1_p_y = msg->y;
}

void nubot2_p_Callback(const nubot_mapping::Pose2D::ConstPtr msg)
{
  n2_p_x = msg->x;
  n2_p_y = msg->y;
}

void nubot3_p_Callback(const nubot_mapping::Pose2D::ConstPtr msg)
{
  n3_p_x = msg->x;
  n3_p_y = msg->y;
}

void nubot1_d_Callback(const std_msgs::Float32::ConstPtr msg)
{
  n1_d = msg->data;
}

void nubot2_d_Callback(const std_msgs::Float32::ConstPtr msg)
{
  n2_d = msg->data;
}

void nubot3_d_Callback(const std_msgs::Float32::ConstPtr msg)
{
  n3_d = msg->data;
}

//////////////////////////////////////////////////////////////////////
/* 6 callbacks above and 3 callbacks below, jadi total 9 callbacks  */
////////////////////////////////WOoOW/////////////////////////////////
//////////////////////////////////////////////////////////////////////

void nubot1_centroid_Callback(const geometry_msgs::Pose2D::ConstPtr msg)
{ 
  nb1_centroid.x = msg->x;
  nb1_centroid.y = msg->y;
  std::cin<<nb1_centroid<<std::endl;
}

void nubot2_centroid_Callback(const geometry_msgs::Pose2D::ConstPtr msg)
{
  nb2_centroid.x = msg->x;
  nb2_centroid.y = msg->y;
}

void nubot3_centroid_Callback(const geometry_msgs::Pose2D::ConstPtr msg)
{
  nb3_centroid.x = msg->x;
  nb3_centroid.y = msg->y;
}



ObjectsCoordinate method_point_titik()
{ 
  /*
  * metode ini dilakukan dengan cara mengambil **selisih point (x,y) pada matriks citra (piksel)  
  * kemudian dikalikan dengan persamaan regresi untuk menghitung estimasi jarak x,y objek dengan robot
  * kemudian ditambahkan dengan nilai posisi robot saat ini. 
  * **selisih yang dimaksud merupakan selisih antara point tengah citra dan titik tengah objek terdeteksi
  */

  // Menghitung delta jarak objek dengan robot dalam ranah piksel
  nubot1_centroid_delta.x = nb1_centroid.x-centerofImage[0]; // Menghitung delta x pada robot 1
  nubot2_centroid_delta.x = nb2_centroid.x-centerofImage[0]; // Menghitung delta x pada robot 2
  nubot3_centroid_delta.x = nb3_centroid.x-centerofImage[0]; // Menghitung delta x pada robot 3
  nubot1_centroid_delta.y = nb1_centroid.y-centerodImage[1]; // Menghitung delta y pada robot 1
  nubot2_centroid_delta.y = nb2_centroid.y-centerofImage[1]; // Menghitung delta y pada robot 2
  nubot3_centroid_delta.y = nb3_centroid.y-centerofImage[1]; // Menghitung delta y pada robot 3
  
  // Menghitung delta jarak robot dan bola dengan dikalika persamaan regresi
  for(int i=1;i<=3;i++)
  {
    nubot_centroid_delta_lapangan[i] = kaliregresi(nubot_centroid_delta[i]);
  }

}

ObjectsCoordinate method_angle_garis()
{
}

ObjectsCoordinate method_combination()
{
}

int main(int argc, char **argv)
{
  ros::init(argc,argv,"nubot_mapping_estimator");
  ros::NodeHandle nh;
  // Subscribe data Estimasi Jarak robot ke bola
  ros::Subscriber sub_nubot1_d = nh.subscribe("/nubot1/estimated_distance_value",1,nubot1_d_Callback);
  ros::Subscriber sub_nubot2_d = nh.subscribe("/nubot2/estimated_distance_value",1,nubot2_d_Callback);
  ros::Subscriber sub_nubot3_d = nh.subscribe("/nubot3/estimated_distance_value",1,nubot3_d_Callback);
  // Subscribe data posisi setiap robot
  ros::Subscriber sub_nubot1_p = nh.subscribe("/nubot1/pose",1,nubot1_p_Callback);
  ros::Subscriber sub_nubot2_p = nh.subscribe("/nubot2/pose",1,nubot2_p_Callback);
  ros::Subscriber sub_nubot3_p = nh.subscribe("/nubot3/pose",1,nubot3_p_Callback);
  // Subscribe data mengenai centroid
  ros::Subscriber sub_nubot1_centroid = nh.subscribe("/nubot1/centroid",1,);
  ros::Subscriber sub_nubot2_centroid = nh.subscribe("/nubot2/centroid",1,);
  ros::Subscriber sub_nubot3_centroid = nh.subscribe("/nubot3/centroid",1,);
  // Subscribe data yang isinya centerofImage
//  ros::Subscriber sub_nubot1_centerofImage = nh.subscribe("/nubot1/centerofImage",1,);
//  ros::Subscriber sub_nubot2_centerofImage = nh.subscribe("/nubot2/centerofImage",1,);
//  ros::Subscriber sub_nubot3_centerofImage = nh.subscribe("/nubot3/centerofImage",1,);
  // method_1();
  // pub_ = nh.advertise<...>("output_value",1);
  
  ros::spin();
  return 0;
}